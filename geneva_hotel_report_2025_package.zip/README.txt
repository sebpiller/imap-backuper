Rapport 2025 des séjours hôteliers dans un rayon de 30 km autour de Genève

Contenu:
- geneva_hotel_report_2025.html: rapport 2025 ouvrable dans un navigateur.
- geneva_hotel_2025_*.csv: données 2025 recalculées avec documents officiels et non officiels exploitables.
- geneva_hotel_2025_concerned_files.csv: liste des documents retenus dans le rapport 2025.
- tools/: scripts permettant de reproduire l'analyse et le rendu HTML.
- documents/: copies des fichiers source retenus, avec leur chemin relatif d'origine.

Synthèse 2025:
- Total retenu: CHF 8'147.55
- Part officielle: CHF 6'211.95
- Part non officielle: CHF 1'935.60
- Séjours avec montant après dédoublonnage: 39
- Nuitées: 74
- Prix moyen: CHF 110.10 / nuit
